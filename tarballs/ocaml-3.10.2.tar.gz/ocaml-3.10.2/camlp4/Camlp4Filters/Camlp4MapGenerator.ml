(* This module is useless now. Camlp4FoldGenerator handles map too. *)
module Id = struct
  value name    = "Camlp4MapGenerator";
  value version = "$Id: Camlp4MapGenerator.ml,v 1.1.4.5 2007/06/23 16:00:09 ertai Exp $";
end;
